# Lolo AI backend

Deploy this folder as a Python web service (for example, Render). Set environment variable `GEMINI_API_KEY` in the hosting dashboard. Do not put the key in source code or share it publicly.

- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn server:app --bind 0.0.0.0:$PORT`
- Health check: `/`
- Chat endpoint: `POST /chat` with JSON `{"message":"سؤالك","history":[]}`

The server calls Gemini's `generateContent` REST endpoint and returns `{"answer":"..."}`.
