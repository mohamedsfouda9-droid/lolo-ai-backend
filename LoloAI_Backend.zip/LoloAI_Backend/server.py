import os
import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '').strip()
GEMINI_MODEL = os.environ.get('GEMINI_MODEL', 'gemini-2.5-flash')

@app.get('/')
def health():
    return jsonify({'ok': True, 'service': 'Lolo AI API'})

@app.post('/chat')
def chat():
    if not GEMINI_API_KEY:
        return jsonify({'error': 'Server is missing GEMINI_API_KEY.'}), 500
    data = request.get_json(silent=True) or {}
    message = str(data.get('message', '')).strip()
    history = data.get('history', [])
    if not message:
        return jsonify({'error': 'اكتب سؤالك الأول.'}), 400
    if len(message) > 12000:
        return jsonify({'error': 'السؤال طويل جدًا. اختصره وجرب تاني.'}), 413

    contents = []
    if isinstance(history, list):
        for item in history[-12:]:
            if not isinstance(item, dict):
                continue
            role = 'model' if item.get('role') == 'assistant' else 'user'
            text = str(item.get('text', '')).strip()[:4000]
            if text:
                contents.append({'role': role, 'parts': [{'text': text}]})
    contents.append({'role': 'user', 'parts': [{'text': message}]})
    payload = {
        'systemInstruction': {'parts': [{'text': 'أنت لولو، مساعدة مذاكرة ودودة لطالب الفرقة الثانية بكلية الزراعة شعبة عامة. أجيبي بالعربية المصرية الواضحة، واشرحي مواد الهندسة الزراعية والرعاية والميكروبيولوجي والكيمياء والمحاصيل والبساتين. رتبي الإجابة في نقاط عند الحاجة، ولا تخترعي معلومات مؤكدة؛ وضحي عندما لا تكونين متأكدة.'}]},
        'contents': contents,
        'generationConfig': {'temperature': 0.7, 'maxOutputTokens': 1200}
    }
    url = f'https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent'
    try:
        response = requests.post(url, headers={'x-goog-api-key': GEMINI_API_KEY, 'Content-Type': 'application/json'}, json=payload, timeout=60)
        result = response.json()
        if not response.ok:
            message = result.get('error', {}).get('message', 'Gemini request failed')
            return jsonify({'error': message}), response.status_code
        candidates = result.get('candidates', [])
        parts = candidates[0].get('content', {}).get('parts', []) if candidates else []
        answer = '\n'.join(p.get('text', '') for p in parts if p.get('text'))
        if not answer:
            return jsonify({'error': 'النموذج لم يرجع إجابة. جرّب سؤالًا آخر.'}), 502
        return jsonify({'answer': answer})
    except requests.Timeout:
        return jsonify({'error': 'الرد اتأخر. جرّب تاني بعد شوية.'}), 504
    except Exception:
        app.logger.exception('Unexpected error while calling Gemini')
        return jsonify({'error': 'حصل خطأ أثناء الاتصال بالمساعد.'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '8080')))
